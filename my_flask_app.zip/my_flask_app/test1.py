import paramiko


with paramiko.SSHClient() as client:
    client.load_system_host_keys()
    client.connect(hostname="10.18.12.177",username="eng")
    stdin, stdout, stderr = client.exec_command("curl http://localhost:5000/create_event/map")
    output = stdout.read()
    print(str(output, 'utf8'))



