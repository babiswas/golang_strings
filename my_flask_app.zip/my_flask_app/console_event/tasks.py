from celery import Celery
import redis

app=Celery('tasks',broker='redis://redis:6379/0',backend='redis://redis:6379/0')

@app.task()
def console_event_task(message:str):
    '''This task creates a console event message'''
    return "Hello"+" "+message