package main

import (
	"FILE_util/DIR_util"
	"FILE_util/File_Ops"
	"flag"
	"fmt"
	"log"
)

func main() {
	fmt.Println("=============Processing file infos in directory===============")
	directory_name := flag.String("fileName", "./DIR_util", "a string")
	flag.Parse()
	dir_path := *directory_name
	file_infos := DIR_util.Read_directory_files_folders(dir_path)
	fmt.Println(file_infos)
	files := DIR_util.Process_all_file_infos(file_infos)
	log.Println("Listing files")
	files_as_string := DIR_util.Process_all_file_infos_string(files)
	fmt.Println(files_as_string)
	fmt.Println("=============Copy file source to destination=================")
	source_path := "./go.mod"
	dest_path := "./DIR_util/go.mod"
	File_Ops.Copy_file_source_destination(source_path, dest_path)
	File_Ops.Remove_created_files(dest_path)
	fmt.Println("===============================================================")

}
