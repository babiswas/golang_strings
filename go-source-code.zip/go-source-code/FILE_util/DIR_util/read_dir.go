package DIR_util

import (
	"fmt"
	"io/ioutil"
	"log"
	"os"
)

func Read_directory_files_folders(directory_path string) []os.FileInfo {
	message := ""
	log.Println("Collecting all the file infos.")
	fileInfos, err := ioutil.ReadDir(directory_path)
	if err != nil {
		message = fmt.Sprintf("Error occured %s", err)
		log.Println(message)
		os.Exit(1)
	}
	log.Println("Returning list of file infos.")
	return fileInfos
}

func Process_all_file_infos(file_infos []os.FileInfo) []MyFileInfo {
	infos := []MyFileInfo{}
	log.Println("Processing the file infos for the files obtained from directory.")
	for _, file_info := range file_infos {
		myfile_info := MyFileInfo{Name: file_info.Name(), Size: file_info.Size(), IsDir: file_info.IsDir()}
		infos = append(infos, myfile_info)
	}
	return infos
}

func Process_all_file_infos_string(infos []MyFileInfo) []string {
	return process_all_file_infos(infos)
}
