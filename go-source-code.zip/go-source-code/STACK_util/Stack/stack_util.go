package Stack

import (
	"fmt"
	"log"
)

func (s *Stack) is_empty() bool {
	log.Println("Checking if the stack is empty.")
	return len(*s) == 0
}

func (s *Stack) Push(val string) {
	message := fmt.Sprintf("Pushing string %s", val)
	log.Println(message)
	*s = append(*s, val)
}

func (s *Stack) Pop() (string, bool) {
	message := ""
	if len(*s) == 0 {
		fmt.Println("Stack is empty.")
		return "", false
	} else {
		index := len(*s) - 1
		element := (*s)[index]
		*s = (*s)[:index]
		message = fmt.Sprintf("Popping from the stack value:%s", element)
		log.Println(message)
		return element, true
	}
}

func (s *Stack) Stack_length() int {
	return len(*s)
}
