package Stack

import "fmt"

type Stack []string

type StackInfo struct {
	currentStack Stack
	stackLength  int
	empty        bool
}

func (s *StackInfo) StackTracker(st Stack, lngth int) {
	s.currentStack = st
	s.stackLength = lngth
	if lngth == 0 {
		s.empty = true
	} else {
		s.empty = false
	}
}

func (s StackInfo) Display() {
	fmt.Println("Current stack values: ", s.currentStack)
	fmt.Println("Current stack length: ", s.stackLength)
	fmt.Println("Is current stack empty:", s.empty)
}
