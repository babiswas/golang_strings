package main

import (
	"STACK_util/Stack"
	"fmt"
)

func main() {
	var stack Stack.Stack
	fmt.Println("=============Populating Stack================")
	stack.Push("hello")
	stack.Push("bello")
	stack.Push("mello")
	stack.Push("tello")
	fmt.Println("=============Popping from the stack==================")
	for stack.Stack_length() != 0 {
		x, y := stack.Pop()
		if y == true {
			fmt.Println(x)
		}
	}
	fmt.Println("================Explored the stack======================")
	fmt.Println("===============Experimenting with stack info ==============")
	var stack1 Stack.Stack
	stack_info := Stack.StackInfo{}
	stack1.Push("hello1")
	stack1.Push("bello1")
	stack1.Push("mello1")
	stack1.Push("tello1")
	stack1.Push("dello1")
	stack_info.StackTracker(stack1, stack1.Stack_length())
	stack_info.Display()
	fmt.Println("===============================================================")
}
