package main

import (
	"fmt"
	"strings"
)

func main() {
	str1 := "hello world"
	if strings.Contains(str1, "world") {
		fmt.Println("substring is present.")
	}
	str2 := strings.ToUpper(str1)
	fmt.Println(str2)
	fmt.Println(strings.HasPrefix(str1, "hello"))
	fmt.Println(strings.HasSuffix(str1, "world"))
	fmt.Println(strings.ToLower(str2))
	return

}
