package RecordModel

import "strconv"

type Student struct {
	Name string
	Mark int
	Roll int
}

func (s Student) Convert_record_string() []string {
	record := make([]string, 0)
	record = append(record, s.Name)
	record = append(record, strconv.Itoa(s.Mark))
	record = append(record, strconv.Itoa(s.Roll))
	return record
}

func Process_all_records(records []Student) [][]string {
	all_records := make([][]string, 0)
	for _, student_obj := range records {
		all_records = append(all_records, student_obj.Convert_record_string())
	}
	return all_records
}
