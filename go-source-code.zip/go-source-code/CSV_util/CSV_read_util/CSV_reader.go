package CSV_read_util

import (
	"encoding/csv"
	"fmt"
	"io"
	"log"
	"os"
	"sync"
)

func CreateReader(ptr *os.File) *csv.Reader {

	log.Println("Creating a csv reader.")
	csv_reader := csv.NewReader(ptr)
	return csv_reader
}

func ProcessCSVLinewise(r *csv.Reader) {

	log.Println("Processing csv line by line.")
	message := ""
	for {
		content, err := r.Read()
		if err == io.EOF {
			message = fmt.Sprintf("File processing complete.")
			log.Println(message)
			break
		}
		if err != nil {
			message = fmt.Sprintf("Error occured %s", err)
			log.Fatal(message)
			os.Exit(1)
		}
		fmt.Println(content)
	}
}

func ProcessCSVLinewiseChannel(r *csv.Reader, ch chan<- []string, wg *sync.WaitGroup) {
	defer wg.Done()
	message := ""
	log.Println("Processing csv linewise and sending it to a channel.")
	for {
		content, err := r.Read()
		if err == io.EOF {
			message = fmt.Sprintf("File processing complete.")
			log.Println(message)
			break
		}
		if err != nil {
			message = fmt.Sprintf("Error occured %s", err)
			log.Fatal(message)
			os.Exit(1)
		}
		ch <- content
	}
	close(ch)
}

func ProcessFullContent(r *csv.Reader) [][]string {
	log.Println("Provide full content of the csv.")
	message := ""
	content, err := r.ReadAll()
	if err != nil {
		message = fmt.Sprintf("Error occured %s", message)
		log.Fatal(message)
		os.Exit(1)
	}
	return content
}
