package main

import (
	"encoding/csv"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"strconv"
)

type Record struct {
	qty, price int
	item       string
}

func read_csv(file_name string) *os.File {
	message := fmt.Sprintf("Opening a file %s", file_name)
	log.Println(message)
	file_descriptor, err := os.Open(file_name)
	if err != nil {
		message = fmt.Sprintf("Error occured %s", err)
		log.Fatal(message)
		os.Exit(1)
	}
	message = fmt.Sprintf("Returning file descriptor.")
	log.Println(message)
	return file_descriptor
}

func store_csv_records(file_ptr *os.File) [][]string {
	defer file_ptr.Close()
	message := fmt.Sprintf("Creating a new reader to read the records.")
	log.Println(message)
	csv_reader := csv.NewReader(file_ptr)
	csv_records_store := make([][]string, 0)
	csv_records, err := csv_reader.ReadAll()
	if err != nil {
		message = fmt.Sprintf("Error occured %s", err)
		log.Fatal(message)
		os.Exit(1)
	}
	for _, record := range csv_records {
		csv_records_store = append(csv_records_store, record)
	}
	message = fmt.Sprintf("Returning csv records")
	log.Println(message)
	return csv_records_store
}

func process_csv_linewise(file_ptr *os.File) {
	defer file_ptr.Close()
	csv_reader := csv.NewReader(file_ptr)
	for {
		line, err := csv_reader.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			message := fmt.Sprintf("Error occured %s", err)
			log.Fatal(message)
		}
		fmt.Printf("%s\n", line[1])
	}
}

func process_records(records [][]string) {
	message := fmt.Sprintf("Processing records in csv.")
	log.Println(message)
	for _, record := range records {
		fmt.Println(record)
	}
	return
}

func write_csv(file_ptr *os.File, records []Record) {
	writer := csv.NewWriter(file_ptr)
	message := ""
	defer writer.Flush()
	for _, record := range records {
		row := []string{strconv.Itoa(record.qty), record.item, strconv.Itoa(record.price)}
		if err := writer.Write(row); err != nil {
			message = fmt.Sprintf("Error occured %s", err)
			log.Fatal(message)
			os.Exit(1)
		}
	}
}

func main() {
	file_name_parser := flag.String("file_name", "testfile.csv", "a string")
	flag.Parse()
	file_name := *file_name_parser
	records := []Record{{qty: 21, item: "Mango", price: 42}, {qty: 211, item: "banana", price: 402}, {qty: 110, item: "Lemon", price: 420}}
	file, err := os.Create(file_name)
	if err != nil {
		message := fmt.Sprintf("Error occured %s", err)
		log.Fatal(message)
		os.Exit(1)
	}
	log.Println("Write csv file.")
	write_csv(file, records)
}
